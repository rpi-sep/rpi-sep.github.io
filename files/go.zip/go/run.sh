#!/usr/bin/env bash

./hello $1
