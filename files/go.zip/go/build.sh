#!/usr/bin/env bash

rm -rf bin
mkdir bin

go build src/hello.go
mv hello bin/
cp run.sh bin/

echo Done!

exit 0
