#!/usr/bin/env bash

./sample $1
