#!/usr/bin/env bash

rm -rf bin
mkdir bin

# --offline is necessary for compilation in Submitty
cargo build --release --offline
mv target/release/sample bin/
cp run.sh bin/

echo Done!

exit 0
