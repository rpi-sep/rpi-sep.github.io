package com.example.client;

public class Module1{
  String str;

  public Module1(String s){
    this.str = s;
  }

  public void printit(){
    System.out.println("My string is " + str);
  }

}