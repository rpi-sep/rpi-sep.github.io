package com.example.server;

public class Module3{

  public Module3(){
  }

  public void printit(){
    System.out.println("Hello World!");
  }

}