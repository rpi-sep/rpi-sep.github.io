#!/usr/bin/env bash

# Run my program.
java -cp . com.example.app.MyApp $1 

exit 0