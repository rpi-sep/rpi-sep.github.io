import sys

if __name__ == '__main__':

  if len(sys.argv) < 2:
    print("ERROR: Please include 1 argument.")
    sys.exit(1)

  print("Hello {0}!".format(sys.argv[1]))
    

