#!/usr/bin/env bash

rm -rf bin
mkdir bin
cp -R src/*  bin/
cp run.sh bin/


echo Done!

exit 0
