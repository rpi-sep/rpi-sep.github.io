#!/usr/bin/env bash

# Run my program.
python3 hello.py $1 

exit 0
